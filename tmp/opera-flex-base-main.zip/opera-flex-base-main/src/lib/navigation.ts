import {
  LayoutDashboard, Wallet, ArrowLeftRight, Landmark, TrendingUp,
  Receipt, Tags, PieChart, Users, Package, Warehouse, Box,
  BarChart3, Repeat, FileCheck, Building2, ShoppingCart, BookOpen,
  FileText, RefreshCw, Store, BarChart2, Shield, UserCog, Key,
  Lock, GitBranch, Settings, ScrollText, ClipboardList, type LucideIcon
} from "lucide-react";

export interface NavItem {
  title: string;
  path?: string;
  icon: LucideIcon;
  permission?: string;
  children?: NavItem[];
}

export const navigation: NavItem[] = [
  { title: "Dashboard", path: "/", icon: LayoutDashboard },
  {
    title: "Finance", icon: Wallet, children: [
      { title: "Transactions", path: "/finance/transactions", icon: ArrowLeftRight },
      { title: "Cash/Bank Accounts", path: "/finance/accounts", icon: Landmark },
      { title: "Income & Payments", path: "/finance/income", icon: TrendingUp },
      { title: "Expenses", path: "/finance/expenses", icon: Receipt },
      { title: "Categories", path: "/finance/categories", icon: Tags },
      { title: "Budgets", path: "/finance/budgets", icon: PieChart },
      { title: "Parties", path: "/finance/parties", icon: Users },
    ]
  },
  {
    title: "Inventory", icon: Package, children: [
      { title: "Warehouses", path: "/inventory/warehouses", icon: Warehouse },
      { title: "Items", path: "/inventory/items", icon: Box },
      { title: "Stock Movements", path: "/inventory/stock", icon: BarChart3 },
      { title: "Transfers", path: "/inventory/transfers", icon: Repeat },
      { title: "Purchase Requests", path: "/inventory/purchases", icon: FileCheck },
      { title: "Capitals", path: "/inventory/capitals", icon: Building2 },
    ]
  },
  {
    title: "Sales & Services", icon: ShoppingCart, children: [
      { title: "Service Catalog", path: "/sales/catalog", icon: BookOpen },
      { title: "Contracts", path: "/sales/contracts", icon: FileText },
      { title: "Recharges & Fees", path: "/sales/recharges", icon: RefreshCw },
      { title: "Product Sales", path: "/sales/products", icon: Store },
    ]
  },
  {
    title: "Reports", icon: BarChart2, children: [
      { title: "Financial Reports", path: "/reports/financial", icon: BarChart2 },
      { title: "Budget vs Actual", path: "/reports/budget", icon: PieChart },
      { title: "Purchases", path: "/reports/purchases", icon: FileCheck },
      { title: "Sales", path: "/reports/sales", icon: ShoppingCart },
      { title: "Inventory", path: "/reports/inventory", icon: Package },
    ]
  },
  {
    title: "Security", icon: Shield, permission: "admin", children: [
      { title: "Users", path: "/security/users", icon: UserCog },
      { title: "Roles", path: "/security/roles", icon: Key },
      { title: "Permissions", path: "/security/permissions", icon: Lock },
      { title: "Branches", path: "/security/branches", icon: GitBranch },
      { title: "Configuration", path: "/security/config", icon: Settings },
    ]
  },
  {
    title: "Logs", icon: ScrollText, permission: "admin", children: [
      { title: "Log Explorer", path: "/logs/explorer", icon: ScrollText },
      { title: "Audit Trail", path: "/logs/audit", icon: ClipboardList },
    ]
  },
];
