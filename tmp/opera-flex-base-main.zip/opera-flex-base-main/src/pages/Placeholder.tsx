import { useLocation } from "react-router-dom";
import { AppShell } from "@/components/layout/AppShell";
import { Construction } from "lucide-react";

export default function Placeholder() {
  const { pathname } = useLocation();
  
  // Derive a readable title from the path
  const title = pathname
    .split("/")
    .filter(Boolean)
    .pop()
    ?.replace(/-/g, " ")
    ?.replace(/\b\w/g, c => c.toUpperCase()) ?? "Page";

  return (
    <AppShell>
      <div className="flex flex-col items-center justify-center py-24 text-center">
        <div className="h-16 w-16 rounded-2xl bg-muted flex items-center justify-center mb-4">
          <Construction className="h-8 w-8 text-muted-foreground" />
        </div>
        <h2 className="text-xl font-semibold text-foreground">{title}</h2>
        <p className="text-sm text-muted-foreground mt-1 max-w-sm">
          This module is under development and will be available soon.
        </p>
      </div>
    </AppShell>
  );
}
