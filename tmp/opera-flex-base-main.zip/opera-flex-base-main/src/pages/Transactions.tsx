import { useState } from "react";
import { Plus, Eye, MoreHorizontal, ArrowUpRight, ArrowDownLeft } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { FilterBar } from "@/components/shared/FilterBar";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const mockTransactions = [
  { id: "TXN-001", date: "2026-02-10", ref: "INV-2026-045", type: "Credit", account: "GTBank Main", counterparty: "Dangote Ltd", amount: 580000, status: "Completed", source: "ProductSale" },
  { id: "TXN-002", date: "2026-02-10", ref: "EXP-2026-112", type: "Debit", account: "GTBank Main", counterparty: "IBEDC", amount: 45000, status: "Completed", source: "Expense" },
  { id: "TXN-003", date: "2026-02-09", ref: "SRV-2026-033", type: "Credit", account: "Access Bank", counterparty: "MTN Nigeria", amount: 250000, status: "Pending", source: "Services" },
  { id: "TXN-004", date: "2026-02-09", ref: "PUR-2026-089", type: "Debit", account: "GTBank Main", counterparty: "Mikano Int'l", amount: 1200000, status: "Completed", source: "Purchase" },
  { id: "TXN-005", date: "2026-02-08", ref: "ADJ-2026-007", type: "Credit", account: "Zenith Bank", counterparty: "—", amount: 95000, status: "Completed", source: "Adjustment" },
  { id: "TXN-006", date: "2026-02-08", ref: "INV-2026-044", type: "Credit", account: "GTBank Main", counterparty: "Flour Mills", amount: 340000, status: "Completed", source: "ProductSale" },
  { id: "TXN-007", date: "2026-02-07", ref: "EXP-2026-111", type: "Debit", account: "Access Bank", counterparty: "DHL Nigeria", amount: 78000, status: "Pending", source: "Expense" },
  { id: "TXN-008", date: "2026-02-07", ref: "RFN-2026-003", type: "Debit", account: "GTBank Main", counterparty: "MTN Nigeria", amount: 50000, status: "Completed", source: "Refund" },
];

export default function Transactions() {
  const [search, setSearch] = useState("");
  const [datePreset, setDatePreset] = useState("3 months");

  const filtered = mockTransactions.filter(t =>
    t.ref.toLowerCase().includes(search.toLowerCase()) ||
    t.counterparty.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppShell>
      <div className="space-y-4 animate-fade-in">
        <div className="page-header">
          <div>
            <h1 className="page-title">Transactions</h1>
            <p className="page-subtitle">Unified transaction ledger across all accounts</p>
          </div>
          <div className="flex items-center gap-2">
            <ExportButtons />
            <Button>
              <Plus className="h-4 w-4 mr-1.5" /> New Transaction
            </Button>
          </div>
        </div>

        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search by reference, counterparty..."
          activeDatePreset={datePreset}
          onDatePresetChange={setDatePreset}
          filters={[
            {
              label: "Type", value: "all",
              options: [{ label: "All Types", value: "all" }, { label: "Credit", value: "credit" }, { label: "Debit", value: "debit" }],
              onChange: () => {},
            },
            {
              label: "Status", value: "all",
              options: [{ label: "All Status", value: "all" }, { label: "Completed", value: "completed" }, { label: "Pending", value: "pending" }],
              onChange: () => {},
            },
          ]}
        />

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead className="w-10"></TableHead>
                <TableHead>Date</TableHead>
                <TableHead>Reference</TableHead>
                <TableHead>Account</TableHead>
                <TableHead>Counterparty</TableHead>
                <TableHead>Source</TableHead>
                <TableHead className="text-right">Amount (₦)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-10"></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(txn => (
                <TableRow key={txn.id} className="data-table-row">
                  <TableCell>
                    <div className={cn(
                      "h-7 w-7 rounded-full flex items-center justify-center",
                      txn.type === "Credit" ? "bg-success/10" : "bg-destructive/10"
                    )}>
                      {txn.type === "Credit"
                        ? <ArrowDownLeft className="h-3.5 w-3.5 text-success" />
                        : <ArrowUpRight className="h-3.5 w-3.5 text-destructive" />
                      }
                    </div>
                  </TableCell>
                  <TableCell className="text-sm">{txn.date}</TableCell>
                  <TableCell className="text-sm font-medium">{txn.ref}</TableCell>
                  <TableCell className="text-sm">{txn.account}</TableCell>
                  <TableCell className="text-sm">{txn.counterparty}</TableCell>
                  <TableCell>
                    <span className="text-xs bg-muted px-2 py-0.5 rounded font-medium">{txn.source}</span>
                  </TableCell>
                  <TableCell className={cn(
                    "text-sm font-semibold text-right",
                    txn.type === "Credit" ? "text-success" : "text-destructive"
                  )}>
                    {txn.type === "Credit" ? "+" : "−"}₦{txn.amount.toLocaleString()}
                  </TableCell>
                  <TableCell><StatusBadge status={txn.status} /></TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon" className="h-7 w-7">
                          <MoreHorizontal className="h-3.5 w-3.5" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem><Eye className="h-3.5 w-3.5 mr-2" /> View Details</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {/* Pagination */}
          <div className="flex items-center justify-between px-4 py-3 border-t border-border text-sm text-muted-foreground">
            <span>Showing 1–{filtered.length} of {filtered.length} transactions</span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" disabled className="h-8">Previous</Button>
              <Button variant="outline" size="sm" className="h-8 bg-primary text-primary-foreground">1</Button>
              <Button variant="outline" size="sm" className="h-8">Next</Button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
