import { DollarSign, TrendingUp, TrendingDown, Wallet, Landmark } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { KpiCard } from "@/components/shared/KpiCard";
import { useApp } from "@/contexts/AppContext";
import {
  LineChart, Line, BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from "recharts";

const incomeExpenseData = [
  { month: "Jul", income: 420000, expenses: 310000 },
  { month: "Aug", income: 380000, expenses: 280000 },
  { month: "Sep", income: 510000, expenses: 340000 },
  { month: "Oct", income: 470000, expenses: 360000 },
  { month: "Nov", income: 530000, expenses: 290000 },
  { month: "Dec", income: 620000, expenses: 410000 },
  { month: "Jan", income: 580000, expenses: 370000 },
];

const budgetActualData = [
  { category: "Operations", budget: 150000, actual: 138000 },
  { category: "Marketing", budget: 80000, actual: 92000 },
  { category: "Logistics", budget: 120000, actual: 110000 },
  { category: "Salaries", budget: 200000, actual: 200000 },
  { category: "Utilities", budget: 45000, actual: 41000 },
];

const expenseByCategoryData = [
  { name: "Salaries", value: 200000 },
  { name: "Logistics", value: 110000 },
  { name: "Operations", value: 138000 },
  { name: "Marketing", value: 92000 },
  { name: "Utilities", value: 41000 },
];

const CHART_COLORS = [
  "hsl(37, 38%, 58%)",
  "hsl(142, 60%, 40%)",
  "hsl(0, 1%, 45%)",
  "hsl(37, 50%, 72%)",
  "hsl(0, 72%, 51%)",
];

export default function Dashboard() {
  const { currentBranch } = useApp();

  return (
    <AppShell>
      <div className="space-y-6 animate-fade-in">
        <div className="page-header">
          <div>
            <h1 className="page-title">Dashboard</h1>
            <p className="page-subtitle">{currentBranch.name} — Financial overview</p>
          </div>
        </div>

        {/* KPI Row */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
          <KpiCard title="Total Income" value="₦3.51M" change="+12.3% vs last period" trend="up" icon={TrendingUp} variant="positive" />
          <KpiCard title="Total Expenses" value="₦2.36M" change="+5.1% vs last period" trend="down" icon={TrendingDown} variant="negative" />
          <KpiCard title="Net Profit" value="₦1.15M" change="+24.8% vs last period" trend="up" icon={DollarSign} variant="positive" />
          <KpiCard title="Gross Margin" value="32.7%" change="+3.2 pts" trend="up" icon={Wallet} variant="neutral" />
          <KpiCard title="Bank Balance" value="₦4.82M" change="Across 3 accounts" trend="neutral" icon={Landmark} variant="neutral" />
        </div>

        {/* Charts Row 1 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-card border border-border rounded-lg p-5">
            <h3 className="text-sm font-semibold text-card-foreground mb-4">Income vs Expenses</h3>
            <ResponsiveContainer width="100%" height={280}>
              <LineChart data={incomeExpenseData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 8%, 88%)" />
                <XAxis dataKey="month" tick={{ fontSize: 12 }} stroke="hsl(0, 1%, 45%)" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(0, 1%, 45%)" tickFormatter={v => `₦${v / 1000}k`} />
                <Tooltip formatter={(v: number) => `₦${v.toLocaleString()}`} />
                <Legend />
                <Line type="monotone" dataKey="income" stroke="hsl(142, 60%, 40%)" strokeWidth={2} dot={{ r: 3 }} name="Income" />
                <Line type="monotone" dataKey="expenses" stroke="hsl(0, 72%, 51%)" strokeWidth={2} dot={{ r: 3 }} name="Expenses" />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-card border border-border rounded-lg p-5">
            <h3 className="text-sm font-semibold text-card-foreground mb-4">Budget vs Actual</h3>
            <ResponsiveContainer width="100%" height={280}>
              <BarChart data={budgetActualData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(30, 8%, 88%)" />
                <XAxis dataKey="category" tick={{ fontSize: 11 }} stroke="hsl(0, 1%, 45%)" />
                <YAxis tick={{ fontSize: 12 }} stroke="hsl(0, 1%, 45%)" tickFormatter={v => `₦${v / 1000}k`} />
                <Tooltip formatter={(v: number) => `₦${v.toLocaleString()}`} />
                <Legend />
                <Bar dataKey="budget" fill="hsl(37, 38%, 58%)" radius={[4, 4, 0, 0]} name="Budget" />
                <Bar dataKey="actual" fill="hsl(37, 38%, 78%)" radius={[4, 4, 0, 0]} name="Actual" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Charts Row 2 */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="bg-card border border-border rounded-lg p-5">
            <h3 className="text-sm font-semibold text-card-foreground mb-4">Expenses by Category</h3>
            <ResponsiveContainer width="100%" height={280}>
              <PieChart>
                <Pie
                  data={expenseByCategoryData} cx="50%" cy="50%"
                  innerRadius={60} outerRadius={100} paddingAngle={3}
                  dataKey="value" nameKey="name"
                >
                  {expenseByCategoryData.map((_, i) => (
                    <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip formatter={(v: number) => `₦${v.toLocaleString()}`} />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-card border border-border rounded-lg p-5">
            <h3 className="text-sm font-semibold text-card-foreground mb-4">Recent Activity</h3>
            <div className="space-y-3">
              {[
                { action: "Expense recorded", detail: "Office supplies — ₦45,000", time: "2 min ago", user: "Aminu Y." },
                { action: "Payment received", detail: "Customer payment — ₦180,000", time: "15 min ago", user: "Fatima A." },
                { action: "Purchase approved", detail: "PR-2024-089 — Network cables", time: "1 hour ago", user: "Ibrahim M." },
                { action: "Stock transfer", detail: "Lagos → Abuja — 50 units", time: "2 hours ago", user: "Aisha B." },
                { action: "Budget updated", detail: "Marketing Q1 2026", time: "3 hours ago", user: "Aminu Y." },
              ].map((item, i) => (
                <div key={i} className="flex items-start justify-between py-2 border-b border-border last:border-0">
                  <div>
                    <p className="text-sm font-medium text-card-foreground">{item.action}</p>
                    <p className="text-xs text-muted-foreground">{item.detail}</p>
                  </div>
                  <div className="text-right shrink-0">
                    <p className="text-xs text-muted-foreground">{item.time}</p>
                    <p className="text-xs text-muted-foreground">{item.user}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
