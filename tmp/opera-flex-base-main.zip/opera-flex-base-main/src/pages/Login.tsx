import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Eye, EyeOff, LogIn } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const navigate = useNavigate();

  return (
    <div className="min-h-screen flex">
      {/* Left panel - branding */}
      <div className="hidden lg:flex lg:w-1/2 bg-sidebar relative overflow-hidden flex-col justify-between p-12">
        <div>
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-sidebar-primary flex items-center justify-center">
              <span className="text-sidebar-primary-foreground font-bold text-lg">2o</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-sidebar-accent-foreground">2ofan</h1>
              <p className="text-xs text-sidebar-foreground">ExpenseTracker</p>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <h2 className="text-3xl font-bold text-sidebar-accent-foreground leading-tight">
            Branch-aware financial<br />& operations platform
          </h2>
          <p className="text-sidebar-foreground text-sm max-w-md leading-relaxed">
            Manage expenses, track inventory, handle sales & services, and generate comprehensive reports — all from a unified, permission-aware dashboard.
          </p>
          <div className="grid grid-cols-3 gap-4 pt-4">
            {["Multi-Branch", "Real-time Reports", "Audit Trail"].map(feature => (
              <div key={feature} className="bg-sidebar-accent rounded-lg p-3 text-center">
                <p className="text-xs font-medium text-sidebar-accent-foreground">{feature}</p>
              </div>
            ))}
          </div>
        </div>

        <p className="text-xs text-sidebar-foreground">© 2026 2ofan Technologies. All rights reserved.</p>

        {/* Decorative circles */}
        <div className="absolute -top-24 -right-24 h-64 w-64 rounded-full bg-sidebar-primary/10" />
        <div className="absolute -bottom-16 -left-16 h-48 w-48 rounded-full bg-sidebar-primary/5" />
      </div>

      {/* Right panel - form */}
      <div className="flex-1 flex items-center justify-center p-8 bg-background">
        <div className="w-full max-w-sm space-y-8">
          <div className="lg:hidden flex items-center gap-2.5 mb-8">
            <div className="h-9 w-9 rounded-lg bg-primary flex items-center justify-center">
              <span className="text-primary-foreground font-bold text-sm">2o</span>
            </div>
            <h1 className="text-lg font-bold">2ofan ExpenseTracker</h1>
          </div>

          <div>
            <h2 className="text-2xl font-bold text-foreground">Welcome back</h2>
            <p className="text-sm text-muted-foreground mt-1">Sign in to your account to continue</p>
          </div>

          <form
            onSubmit={e => { e.preventDefault(); navigate("/"); }}
            className="space-y-4"
          >
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="you@company.com" defaultValue="aminu@2ofan.com" className="h-10" />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="password">Password</Label>
                <Link to="/forgot-password" className="text-xs text-primary hover:underline">
                  Forgot password?
                </Link>
              </div>
              <div className="relative">
                <Input
                  id="password" type={showPassword ? "text" : "password"}
                  placeholder="••••••••" defaultValue="password" className="h-10 pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <Checkbox id="remember" />
              <Label htmlFor="remember" className="text-sm font-normal text-muted-foreground">
                Remember me for 30 days
              </Label>
            </div>

            <Button type="submit" className="w-full h-10">
              <LogIn className="h-4 w-4 mr-2" /> Sign in
            </Button>
          </form>
        </div>
      </div>
    </div>
  );
}
