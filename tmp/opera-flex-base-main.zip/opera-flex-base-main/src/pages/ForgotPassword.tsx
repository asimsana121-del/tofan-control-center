import { useState } from "react";
import { Link } from "react-router-dom";
import { ArrowLeft, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export default function ForgotPassword() {
  const [sent, setSent] = useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-8">
      <div className="w-full max-w-sm space-y-6">
        <Link to="/login" className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground">
          <ArrowLeft className="h-3.5 w-3.5 mr-1" /> Back to login
        </Link>

        <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center">
          <Mail className="h-6 w-6 text-primary" />
        </div>

        {!sent ? (
          <>
            <div>
              <h2 className="text-2xl font-bold text-foreground">Forgot password?</h2>
              <p className="text-sm text-muted-foreground mt-1">
                Enter your email and we'll send you a reset link.
              </p>
            </div>

            <form onSubmit={e => { e.preventDefault(); setSent(true); }} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="you@company.com" className="h-10" />
              </div>
              <Button type="submit" className="w-full h-10">Send reset link</Button>
            </form>
          </>
        ) : (
          <div>
            <h2 className="text-2xl font-bold text-foreground">Check your email</h2>
            <p className="text-sm text-muted-foreground mt-1">
              We've sent a password reset link to your email address. The link will expire in 1 hour.
            </p>
            <Button variant="outline" className="w-full mt-6" onClick={() => setSent(false)}>
              Resend email
            </Button>
          </div>
        )}
      </div>
    </div>
  );
}
