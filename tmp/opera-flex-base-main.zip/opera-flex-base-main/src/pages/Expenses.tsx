import { useState } from "react";
import { Plus, Receipt } from "lucide-react";
import { AppShell } from "@/components/layout/AppShell";
import { FilterBar } from "@/components/shared/FilterBar";
import { ExportButtons } from "@/components/shared/ExportButtons";
import { StatusBadge } from "@/components/shared/StatusBadge";
import { KpiCard } from "@/components/shared/KpiCard";
import { Button } from "@/components/ui/button";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { DollarSign, TrendingDown, Wallet } from "lucide-react";

const mockExpenses = [
  { id: 1, date: "2026-02-10", description: "Office Supplies", category: "Operations", party: "Shoprite", amount: 45000, branch: "HQ", status: "Approved" },
  { id: 2, date: "2026-02-09", description: "Generator Diesel", category: "Utilities", party: "Total Energies", amount: 120000, branch: "Lagos", status: "Approved" },
  { id: 3, date: "2026-02-09", description: "Staff Transport", category: "Logistics", party: "—", amount: 35000, branch: "HQ", status: "Pending" },
  { id: 4, date: "2026-02-08", description: "Marketing Campaign", category: "Marketing", party: "Facebook Ads", amount: 92000, branch: "HQ", status: "Approved" },
  { id: 5, date: "2026-02-08", description: "Internet Subscription", category: "Utilities", party: "Spectranet", amount: 25000, branch: "Abuja", status: "Approved" },
  { id: 6, date: "2026-02-07", description: "Equipment Repair", category: "Operations", party: "TechFix Ltd", amount: 68000, branch: "Kano", status: "Pending" },
];

export default function Expenses() {
  const [search, setSearch] = useState("");

  const filtered = mockExpenses.filter(e =>
    e.description.toLowerCase().includes(search.toLowerCase()) ||
    e.party.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <AppShell>
      <div className="space-y-4 animate-fade-in">
        <div className="page-header">
          <div>
            <h1 className="page-title">Expenses</h1>
            <p className="page-subtitle">Track and manage all branch expenses</p>
          </div>
          <div className="flex items-center gap-2">
            <ExportButtons />
            <Button>
              <Plus className="h-4 w-4 mr-1.5" /> Add Expense
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <KpiCard title="Total This Month" value="₦385,000" change="-8.2% vs last month" trend="down" icon={DollarSign} variant="negative" />
          <KpiCard title="Pending Approval" value="₦103,000" change="2 items pending" trend="neutral" icon={Receipt} variant="neutral" />
          <KpiCard title="Budget Remaining" value="₦215,000" change="35.8% of budget used" trend="neutral" icon={Wallet} variant="positive" />
        </div>

        <FilterBar
          searchValue={search}
          onSearchChange={setSearch}
          searchPlaceholder="Search expenses..."
          filters={[
            {
              label: "Category", value: "all",
              options: [
                { label: "All Categories", value: "all" },
                { label: "Operations", value: "operations" },
                { label: "Utilities", value: "utilities" },
                { label: "Logistics", value: "logistics" },
                { label: "Marketing", value: "marketing" },
              ],
              onChange: () => {},
            },
          ]}
        />

        <div className="bg-card border border-border rounded-lg overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow className="bg-muted/50">
                <TableHead>Date</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Category</TableHead>
                <TableHead>Party</TableHead>
                <TableHead>Branch</TableHead>
                <TableHead className="text-right">Amount (₦)</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map(exp => (
                <TableRow key={exp.id} className="data-table-row">
                  <TableCell className="text-sm">{exp.date}</TableCell>
                  <TableCell className="text-sm font-medium">{exp.description}</TableCell>
                  <TableCell>
                    <span className="text-xs bg-muted px-2 py-0.5 rounded font-medium">{exp.category}</span>
                  </TableCell>
                  <TableCell className="text-sm">{exp.party}</TableCell>
                  <TableCell className="text-sm">{exp.branch}</TableCell>
                  <TableCell className="text-sm font-semibold text-right text-destructive">
                    −₦{exp.amount.toLocaleString()}
                  </TableCell>
                  <TableCell><StatusBadge status={exp.status} /></TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          <div className="flex items-center justify-between px-4 py-3 border-t border-border text-sm text-muted-foreground">
            <span>Showing {filtered.length} expenses</span>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="sm" disabled className="h-8">Previous</Button>
              <Button variant="outline" size="sm" className="h-8 bg-primary text-primary-foreground">1</Button>
              <Button variant="outline" size="sm" className="h-8">Next</Button>
            </div>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
