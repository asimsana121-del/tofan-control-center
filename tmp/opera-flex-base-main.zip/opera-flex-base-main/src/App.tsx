import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { ThemeProvider } from "next-themes";
import { AppProvider } from "@/contexts/AppContext";
import Index from "./pages/Index";
import Login from "./pages/Login";
import ForgotPassword from "./pages/ForgotPassword";
import Transactions from "./pages/Transactions";
import Expenses from "./pages/Expenses";
import Placeholder from "./pages/Placeholder";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <ThemeProvider attribute="class" defaultTheme="light" storageKey="tofan-theme">
      <TooltipProvider>
        <AppProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/login" element={<Login />} />
              <Route path="/forgot-password" element={<ForgotPassword />} />
              <Route path="/finance/transactions" element={<Transactions />} />
              <Route path="/finance/expenses" element={<Expenses />} />
              <Route path="/finance/accounts" element={<Placeholder />} />
              <Route path="/finance/income" element={<Placeholder />} />
              <Route path="/finance/categories" element={<Placeholder />} />
              <Route path="/finance/budgets" element={<Placeholder />} />
              <Route path="/finance/parties" element={<Placeholder />} />
              <Route path="/inventory/*" element={<Placeholder />} />
              <Route path="/sales/*" element={<Placeholder />} />
              <Route path="/reports/*" element={<Placeholder />} />
              <Route path="/security/*" element={<Placeholder />} />
              <Route path="/logs/*" element={<Placeholder />} />
              {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </AppProvider>
      </TooltipProvider>
    </ThemeProvider>
  </QueryClientProvider>
);

export default App;
