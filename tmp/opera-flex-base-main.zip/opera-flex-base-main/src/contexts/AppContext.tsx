import React, { createContext, useContext, useState, type ReactNode } from "react";

interface Branch {
  id: string;
  name: string;
}

interface AppUser {
  name: string;
  email: string;
  role: string;
  branchId: string;
  permissions: string[];
  avatar?: string;
}

interface AppContextType {
  sidebarCollapsed: boolean;
  setSidebarCollapsed: (v: boolean) => void;
  currentBranch: Branch;
  setCurrentBranch: (b: Branch) => void;
  branches: Branch[];
  user: AppUser;
  hasPermission: (perm: string) => boolean;
}

const branches: Branch[] = [
  { id: "hq", name: "Headquarters" },
  { id: "br1", name: "Branch 1 — Lagos" },
  { id: "br2", name: "Branch 2 — Abuja" },
  { id: "br3", name: "Branch 3 — Kano" },
];

const mockUser: AppUser = {
  name: "Aminu Yusuf",
  email: "aminu@2ofan.com",
  role: "Admin",
  branchId: "hq",
  permissions: ["admin", "finance", "inventory", "sales", "reports", "logs"],
};

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [currentBranch, setCurrentBranch] = useState(branches[0]);

  const hasPermission = (perm: string) => {
    if (mockUser.role === "Admin") return true;
    return mockUser.permissions.includes(perm);
  };

  return (
    <AppContext.Provider value={{
      sidebarCollapsed, setSidebarCollapsed,
      currentBranch, setCurrentBranch,
      branches, user: mockUser, hasPermission,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
