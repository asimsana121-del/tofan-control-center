import { GitBranch } from "lucide-react";
import { useApp } from "@/contexts/AppContext";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";

export function BranchSwitcher() {
  const { currentBranch, setCurrentBranch, branches } = useApp();

  return (
    <Select
      value={currentBranch.id}
      onValueChange={id => {
        const b = branches.find(b => b.id === id);
        if (b) setCurrentBranch(b);
      }}
    >
      <SelectTrigger className="w-[200px] h-9 text-sm bg-card">
        <GitBranch className="h-3.5 w-3.5 mr-1.5 text-muted-foreground" />
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        {branches.map(b => (
          <SelectItem key={b.id} value={b.id}>{b.name}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}
