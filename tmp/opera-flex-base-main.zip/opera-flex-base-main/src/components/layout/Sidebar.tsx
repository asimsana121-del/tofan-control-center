import { useState } from "react";
import { useLocation, Link } from "react-router-dom";
import { ChevronDown, ChevronLeft, ChevronRight } from "lucide-react";
import { navigation, type NavItem } from "@/lib/navigation";
import { useApp } from "@/contexts/AppContext";
import { cn } from "@/lib/utils";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

function NavItemLink({ item, collapsed }: { item: NavItem; collapsed: boolean }) {
  const { pathname } = useLocation();
  const active = item.path === pathname;
  const Icon = item.icon;

  const link = (
    <Link
      to={item.path || "#"}
      className={cn("sidebar-item", active && "sidebar-item-active")}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {!collapsed && <span className="truncate">{item.title}</span>}
    </Link>
  );

  if (collapsed) {
    return (
      <Tooltip delayDuration={0}>
        <TooltipTrigger asChild>{link}</TooltipTrigger>
        <TooltipContent side="right" className="font-medium">
          {item.title}
        </TooltipContent>
      </Tooltip>
    );
  }

  return link;
}

function NavGroup({ item, collapsed }: { item: NavItem; collapsed: boolean }) {
  const { pathname } = useLocation();
  const { hasPermission } = useApp();
  const hasActiveChild = item.children?.some(c => c.path === pathname);
  const [open, setOpen] = useState(hasActiveChild || false);
  const Icon = item.icon;

  if (item.permission && !hasPermission(item.permission)) return null;

  if (collapsed) {
    return (
      <div className="space-y-0.5">
        <Tooltip delayDuration={0}>
          <TooltipTrigger asChild>
            <button className={cn("sidebar-item w-full", hasActiveChild && "sidebar-item-active")}>
              <Icon className="h-4 w-4 shrink-0" />
            </button>
          </TooltipTrigger>
          <TooltipContent side="right" className="font-medium">
            <div className="space-y-1">
              <p className="font-semibold text-xs uppercase tracking-wider mb-2">{item.title}</p>
              {item.children?.map(child => (
                <Link
                  key={child.title}
                  to={child.path || "#"}
                  className={cn(
                    "block px-2 py-1 rounded text-sm hover:bg-accent",
                    child.path === pathname && "text-primary font-medium"
                  )}
                >
                  {child.title}
                </Link>
              ))}
            </div>
          </TooltipContent>
        </Tooltip>
      </div>
    );
  }

  return (
    <div>
      <button
        onClick={() => setOpen(!open)}
        className={cn("sidebar-item w-full justify-between", hasActiveChild && "sidebar-item-active")}
      >
        <span className="flex items-center gap-3">
          <Icon className="h-4 w-4 shrink-0" />
          <span className="truncate">{item.title}</span>
        </span>
        <ChevronDown className={cn("h-3.5 w-3.5 transition-transform", open && "rotate-180")} />
      </button>
      {open && (
        <div className="ml-4 mt-0.5 space-y-0.5 border-l border-sidebar-border pl-3">
          {item.children?.map(child => (
            <NavItemLink key={child.title} item={child} collapsed={false} />
          ))}
        </div>
      )}
    </div>
  );
}

export function Sidebar() {
  const { sidebarCollapsed, setSidebarCollapsed } = useApp();

  return (
    <aside
      className={cn(
        "fixed left-0 top-0 bottom-0 z-40 flex flex-col bg-sidebar border-r border-sidebar-border transition-all duration-200 scrollbar-thin overflow-y-auto overflow-x-hidden",
        sidebarCollapsed ? "w-16" : "w-[260px]"
      )}
    >
      {/* Logo */}
      <div className={cn("flex items-center h-14 px-4 border-b border-sidebar-border shrink-0", sidebarCollapsed && "justify-center px-2")}>
        {!sidebarCollapsed ? (
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
              <span className="text-sidebar-primary-foreground font-bold text-sm">2o</span>
            </div>
            <div>
              <h1 className="text-sm font-bold text-sidebar-accent-foreground leading-none">2ofan</h1>
              <p className="text-[10px] text-sidebar-foreground leading-none mt-0.5">ExpenseTracker</p>
            </div>
          </div>
        ) : (
          <div className="h-8 w-8 rounded-lg bg-sidebar-primary flex items-center justify-center">
            <span className="text-sidebar-primary-foreground font-bold text-sm">2o</span>
          </div>
        )}
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-3 px-2 space-y-0.5">
        {navigation.map(item =>
          item.children ? (
            <NavGroup key={item.title} item={item} collapsed={sidebarCollapsed} />
          ) : (
            <NavItemLink key={item.title} item={item} collapsed={sidebarCollapsed} />
          )
        )}
      </nav>

      {/* Collapse toggle */}
      <div className="p-2 border-t border-sidebar-border shrink-0">
        <button
          onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          className="sidebar-item w-full justify-center"
        >
          {sidebarCollapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
          {!sidebarCollapsed && <span className="text-xs">Collapse</span>}
        </button>
      </div>
    </aside>
  );
}
