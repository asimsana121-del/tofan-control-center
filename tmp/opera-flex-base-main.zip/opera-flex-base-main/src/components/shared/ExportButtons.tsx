import { Download, FileSpreadsheet, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function ExportButtons({ onExport }: { onExport?: (format: string) => void }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" size="sm" className="h-9">
          <Download className="h-3.5 w-3.5 mr-1.5" /> Export
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        <DropdownMenuItem onClick={() => onExport?.("excel")}>
          <FileSpreadsheet className="h-3.5 w-3.5 mr-2" /> Export to Excel
        </DropdownMenuItem>
        <DropdownMenuItem onClick={() => onExport?.("pdf")}>
          <FileText className="h-3.5 w-3.5 mr-2" /> Export to PDF
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
