import { Clock, User, GitBranch } from "lucide-react";
import { Separator } from "@/components/ui/separator";

interface AuditInfoProps {
  createdBy: string;
  createdAt: string;
  updatedBy?: string;
  updatedAt?: string;
  branch: string;
}

export function AuditInfo({ createdBy, createdAt, updatedBy, updatedAt, branch }: AuditInfoProps) {
  return (
    <div className="bg-muted/50 rounded-lg p-4 text-sm space-y-2">
      <p className="font-medium text-xs uppercase tracking-wider text-muted-foreground mb-3">Audit Information</p>
      <div className="grid grid-cols-2 gap-3">
        <div className="flex items-center gap-2 text-muted-foreground">
          <User className="h-3.5 w-3.5" />
          <span>Created by <span className="text-foreground font-medium">{createdBy}</span></span>
        </div>
        <div className="flex items-center gap-2 text-muted-foreground">
          <Clock className="h-3.5 w-3.5" />
          <span>{createdAt}</span>
        </div>
        {updatedBy && (
          <>
            <div className="flex items-center gap-2 text-muted-foreground">
              <User className="h-3.5 w-3.5" />
              <span>Updated by <span className="text-foreground font-medium">{updatedBy}</span></span>
            </div>
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="h-3.5 w-3.5" />
              <span>{updatedAt}</span>
            </div>
          </>
        )}
      </div>
      <Separator className="my-2" />
      <div className="flex items-center gap-2 text-muted-foreground">
        <GitBranch className="h-3.5 w-3.5" />
        <span>Branch: <span className="text-foreground font-medium">{branch}</span></span>
      </div>
    </div>
  );
}
