import { cn } from "@/lib/utils";

type StatusVariant = "success" | "warning" | "error" | "info" | "default" | "draft";

const variants: Record<StatusVariant, string> = {
  success: "bg-success/10 text-success border-success/20",
  warning: "bg-warning/10 text-warning border-warning/20",
  error: "bg-destructive/10 text-destructive border-destructive/20",
  info: "bg-info/10 text-info border-info/20",
  default: "bg-muted text-muted-foreground border-border",
  draft: "bg-muted text-muted-foreground border-border",
};

const statusMap: Record<string, StatusVariant> = {
  Active: "success", Completed: "success", Approved: "success", Paid: "success",
  Pending: "warning", Draft: "draft", "In Review": "warning",
  Expired: "error", Rejected: "error", Failed: "error", Overdue: "error",
  Cancelled: "default", Inactive: "default",
};

export function StatusBadge({ status, className }: { status: string; className?: string }) {
  const variant = statusMap[status] || "default";
  return (
    <span className={cn(
      "inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium border",
      variants[variant],
      className
    )}>
      {status}
    </span>
  );
}
