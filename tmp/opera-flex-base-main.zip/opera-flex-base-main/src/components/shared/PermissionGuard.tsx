import type { ReactNode } from "react";
import { ShieldOff } from "lucide-react";
import { useApp } from "@/contexts/AppContext";

export function PermissionGuard({ permission, children }: { permission: string; children: ReactNode }) {
  const { hasPermission } = useApp();

  if (!hasPermission(permission)) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-center">
        <div className="h-16 w-16 rounded-2xl bg-destructive/10 flex items-center justify-center mb-4">
          <ShieldOff className="h-8 w-8 text-destructive" />
        </div>
        <h3 className="text-lg font-semibold text-foreground">Access Denied</h3>
        <p className="text-sm text-muted-foreground mt-1 max-w-sm">
          You don't have permission to access this section. Contact your administrator to request access.
        </p>
      </div>
    );
  }

  return <>{children}</>;
}
