import { Search, Calendar, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

interface FilterOption {
  label: string;
  value: string;
}

interface FilterBarProps {
  searchValue: string;
  onSearchChange: (v: string) => void;
  searchPlaceholder?: string;
  datePresets?: string[];
  activeDatePreset?: string;
  onDatePresetChange?: (v: string) => void;
  filters?: { label: string; options: FilterOption[]; value: string; onChange: (v: string) => void }[];
  onClearAll?: () => void;
}

export function FilterBar({
  searchValue, onSearchChange, searchPlaceholder = "Search...",
  datePresets = ["3 months", "6 months", "12 months", "Custom"],
  activeDatePreset = "3 months", onDatePresetChange,
  filters = [], onClearAll,
}: FilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-3 bg-card border border-border rounded-lg p-3">
      <div className="relative flex-1 min-w-[200px]">
        <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
        <Input
          value={searchValue}
          onChange={e => onSearchChange(e.target.value)}
          placeholder={searchPlaceholder}
          className="pl-8 h-9 text-sm bg-background"
        />
      </div>

      <div className="flex items-center gap-1.5">
        <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
        {datePresets.map(preset => (
          <button
            key={preset}
            onClick={() => onDatePresetChange?.(preset)}
            className={cn(
              "filter-chip",
              preset === activeDatePreset ? "filter-chip-active" : "filter-chip-inactive"
            )}
          >
            {preset}
          </button>
        ))}
      </div>

      {filters.map(filter => (
        <Select key={filter.label} value={filter.value} onValueChange={filter.onChange}>
          <SelectTrigger className="h-9 w-[140px] text-sm bg-background">
            <SelectValue placeholder={filter.label} />
          </SelectTrigger>
          <SelectContent>
            {filter.options.map(opt => (
              <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      ))}

      {onClearAll && (
        <Button variant="ghost" size="sm" onClick={onClearAll} className="text-xs h-8">
          <X className="h-3 w-3 mr-1" /> Clear
        </Button>
      )}
    </div>
  );
}
